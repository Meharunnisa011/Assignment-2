function App() {
  const name = "Meharunnisa";
  const today = new Date().toLocaleDateString();
  const a = 10;
  const b = 20;

  return (
    <div>
      <h2>My Details</h2>
      <p>Name: {name}</p>
      <p>Today's Date: {today}</p>
      <p>Sum: {a + b}</p>
    </div>
  );
}

export default App;
