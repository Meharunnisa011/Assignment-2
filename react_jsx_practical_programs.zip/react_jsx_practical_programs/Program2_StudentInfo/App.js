import StudentInfo from "./StudentInfo";

function App() {
  return (
    <StudentInfo
      name="Meharunnisa"
      age={19}
      course="B.Tech CSE"
    />
  );
}

export default App;
