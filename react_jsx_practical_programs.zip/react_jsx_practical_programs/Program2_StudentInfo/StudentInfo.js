const StudentInfo = ({ name, age, course }) => {
  const student = { name, age, course };
  const newStudent = { ...student };

  return (
    <div>
      <h2>Student Details</h2>
      <p>{`Name: ${newStudent.name}`}</p>
      <p>{`Age: ${newStudent.age}`}</p>
      <p>{`Course: ${newStudent.course}`}</p>
    </div>
  );
};

export default StudentInfo;
