import { useState } from "react";

function App() {
  const [dark, setDark] = useState(false);
  const items = ["HTML", "CSS", "JavaScript", "React"];

  const style = {
    backgroundColor: dark ? "black" : "white",
    color: dark ? "white" : "black",
    padding: "20px",
    minHeight: "200px"
  };

  return (
    <div style={style}>
      <h2>My Subjects</h2>

      <ul>
        {items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>

      <button onClick={() => setDark(!dark)}>
        Toggle Dark Mode
      </button>
    </div>
  );
}

export default App;
