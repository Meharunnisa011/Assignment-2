# React JSX Practical Programs

This repository contains three beginner-friendly React programs:

1. **Program 1 — Name, Date and Sum:** Uses JavaScript expressions inside JSX.
2. **Program 2 — Student Information:** Uses an arrow function, object destructuring, template literals, and the spread operator.
3. **Program 3 — List and Dark Mode:** Uses `Array.map()` to display a list and `useState()` to toggle light/dark mode.

## Files

Each program has its own folder containing:
- `App.js` — Main React component
- `main.jsx` — React entry point
- `index.html` — HTML page

## Run a program

These folders contain the source files for a Vite React project. To run one program:

1. Create a Vite React project with `npm create vite@latest my-react-app -- --template react`.
2. Open the created project folder.
3. Copy the three files from **one** program folder into the project's `src` folder, except `index.html`, which goes in the project root.
4. Install dependencies using `npm install`.
5. Start the project using `npm run dev`.

Run one program at a time in a separate Vite project, or replace the files in the same project when switching programs.
